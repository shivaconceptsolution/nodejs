module.exports.a=	"Welcome in sdjhfgdjafg hdfgd gf df vd gjf dfggjdg fg dfg dhfg dygf"
module.exports.b = 100
module.exports.c =20.2

module.exports.p = {
    firstName: 'James',
    lastName: 'Bond'
}

