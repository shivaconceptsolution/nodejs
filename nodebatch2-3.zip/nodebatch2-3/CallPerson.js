var person = require('./bao/Person.js');
var p = new person("Ravi","kumar")
console.log(p.fullName())