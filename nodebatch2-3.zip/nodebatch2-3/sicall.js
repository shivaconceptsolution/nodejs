var http = require('http');
var ref = require('./simodule');
http.createServer(function (req, res) {
 res.writeHead(200, {'Content-Type': 'text/html'});
 res.write("result is " + ref.sicalc());
 res.write("result is "+ref.addition())
 res.end();
}).listen(8080);
console.log("Program started at localhost 8080");