console.log("welcome")
var http = require('http');
http.createServer(function (req, res) {
 res.writeHead(200, {'Content-Type': 'text/html'});
 res.write("<h1>hello world</h1>");
 res.end();
}).listen(8080);
console.log("Program started at localhost 8080");	