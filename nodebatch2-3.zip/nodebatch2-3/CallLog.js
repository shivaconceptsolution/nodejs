var myLogModule = require('./Log.js');
var msg = require('./message.js');

myLogModule.info('Node.js started');
console.log(msg.a)
console.log(msg.b)
console.log(msg.c)	
console.log(msg.p.firstName + " " + msg.p.lastName)