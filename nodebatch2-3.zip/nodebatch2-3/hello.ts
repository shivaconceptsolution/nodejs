let a=10
{
   a=20
}
console.log("global",a)