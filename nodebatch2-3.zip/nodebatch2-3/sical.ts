function calculatesi(p,r,t)
{
	return (p*r*t)/100
}

console.log(calculatesi(450000,2,2))