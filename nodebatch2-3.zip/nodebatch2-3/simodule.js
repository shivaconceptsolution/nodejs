exports.sicalc=function()
{
   p=12000;
   r=2.2;
   t=2;
   si = (p*r*t)/100
   return si;		

}

exports.addition=function()
{
	a=100;
	b=200;
	c=a+b;
	return c;
}